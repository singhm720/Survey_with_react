class Survey < ApplicationRecord
    validates :name, presence: true
end
